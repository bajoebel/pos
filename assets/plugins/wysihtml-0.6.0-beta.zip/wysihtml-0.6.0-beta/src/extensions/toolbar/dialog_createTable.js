(function(wysihtml) {
  wysihtml.toolbar.Dialog_createTable = wysihtml.toolbar.Dialog.extend({
    show: function(elementToChange) {
      this.base(elementToChange);
    }
  });
})(wysihtml);
